let productos = [
  {
    type: "HDCVI - XVR COOPER AI - 8CH",
    code: "DH-XVR1B16-I-V2",
    price: 250000,
    category: "dvr",
    img: "https://tse3.mm.bing.net/th?id=OIP.xtPQbD2vN_8EcjVYc3BtoAHaCy&pid=Api&P=0&h=180",
    descripcion:
      "XVR 16CH + 2CH IP GRABACION HASTA 1080N 4CH CON SMD 1 HDMI 1 E/S RCA 1 SATA AI CODING/H.265",
  },
  {
    type: "HDCVI - XVR COOPER AI - 16CH",
    code: "DH-XVR5216AN-I3",
    price: 200000,
    category: "dvr",
    img: "https://material.dahuasecurity.com/uploads/image/20221202/XVR5216AN-I3-16P_3_thumb.png",
    descripcion:
      "XVR 4 EN 1 AI 16CH GRABACIÓN HASTA 5M-N@10FPS MÁS 8 CH IP MAX 6MP H.265+ 2 SATA HASTA 10TB 1P HDMI",
  },
  {
    type: "HDCVI - XVR COOPER AI - 16CH",
    code: "DH-XVR7216AN-4K-I3",
    price: 2500000,
    category: "dvr",
    img: "https://www.talkcom.my/v2/1159-large_default/dhi-xvr7216an-4kl-x.jpg",
    descripcion:
      "XVR16CH CVI8MP-AHD/TVI 5MP U 64CH IP A12MP GRABACION HASTA 8MP 2HDMI 1VGA 2SATA H265+ ALARMA E/S16/3",
  },
  {
    type: "HDCVI - XVR COOPER AI - 16CH",
    code: "DH-XVR5216AN-4KL-I3",
    price: 1200000,
    category: "dvr",
    img: "https://www.noktaelektronik.net/uploads/urunler/small/191201DXCFBD_k.jpg",
    descripcion:
      "XVR 4 EN 1 AI 16CH MÁS 16 CH IP H.265 H.265+ MAX 8MP 2 SATA 1P HDMI RS485",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - 1080P BALAS",
    code: "DH-HAC-HFW1200RN-0280B-S5",
    price: 62000,
    category: "camara",
    img: "https://www.gvscolombia.com/assets/productos/highres/DH-HAC-HFW1200RN-0280B.png",
    descripcion:
      "CAMARA 4 EN 1 1/2,7 CMOS 1080P TIPO BALA PLASTICA LENTE 2,8MM FOV 103° DWDR IR 20M IP67",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - 1080P BALAS",
    code: "DH-HAC-HFW1200TN-0360B-S5",
    price: 76000,
    category: "camara",
    img: "https://e-catalog.com/jpg_zoom1/1853298.jpg",
    descripcion:
      "CAMARA 4 EN 1 1/2,7 CMOS 1080P TIPO BALA METALICA LENTE 3,6MM FOV 87.5° IR 30M IP67",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - 1080P BALAS",
    code: "DH-HAC-B2A21N-A-0280B",
    price: 68000,
    category: "camara",
    img: "https://copselectronics.com/wp-content/uploads/2021/10/DH-HAC-B2A21N-0280B.jpg",
    descripcion:
      "CAMARA 4 EN 1 1/2,7 CMOS 1080P TIPO BALA METALICA 2,8MM FOV 93° DWDR IR 20M IP67 CON AUDIO",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - 1080P BALAS",
    code: "DH-HAC-HFW1200TN-0360B-S5",
    price: 90000,
    category: "camara",
    img: "https://www.napad.pl/data/katalog/produkty/duze/11154_kamera_analog_hd_2mpx_dh_hac_hfw1200t_0280b_black_s5_glowne_l_.jpg",
    descripcion:
      "CAMARA 4 EN 1 1/2,7 CMOS 1080P TIPO BALA PLASTICA 3,6MM FOV 87,5 ARRAY IR 80M IP67 CON MIC.",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - 1080P BALAS",
    code: "DH-HAC-HFW1200TLMN-I6-A-0360B-S6",
    price: 100000,
    category: "camara",
    img: "https://www.vonmag.ro/assets/img/products/hac-hfw1200tlm-il-a-0360b-s6_1.jpg",
    descripcion:
      "CAMARA 4 EN 1 1/2,7 CMOS 1080P TIPO BALA PLASTICA 3,6MM FOV 87,5 ARRAY IR 80M IP67 CON MIC.",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - DOMOS FULLCOLOR",
    code: "DH-HAC-T1A29N-0280B",
    price: 64000,
    category: "camara",
    img: "https://telefoniatotal.com/wp-content/uploads/2023/04/Camara20Dahua_DH-HAC-HDW1200MN-0280B-S4.png",
    descripcion:
      "CAMARA FULL COLOR 4 EN 1 1/2,8 CMOS 1080P TORRETA PLASTICA LENTE 2,8MM DWDR 20M LUZ BLANCA IP67",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - DOMOS FULLCOLOR",
    code: "DH-HAC-HDW1209CLQN-A-LED-0280B-S2",
    price: 80000,
    category: "camara",
    img: "https://www.polvision.eu/userdata/public/gfx/7330/HAC-HDW1509T-A-LED-0280B-S2_10198_0.jpg",
    descripcion:
      "CAMARA 4 EN 1 FULLCOLOR 1080P TORRETA PLASTICA 2,8MM CON AUDIO LUZ BLANCA 20M IP67",
  },
  {
    type: "HDCVI - 4 EN 1 DAHUA - DOMOS FULLCOLOR",
    code: "DH-HAC-HDW1209TLQN-LED-0280B",
    price: 90000,
    category: "camara",
    img: "https://tse3.mm.bing.net/th?id=OIP.M_bHD0TpJ15T7pH2hjkAXAHaHa&pid=Api&P=0&h=180",
    descripcion:
      "CAMARA 4 EN 1 FULLCOLOR 1080P TIPO DOMO SEMIMETALICO 2,8MM FOV 106° LUZ VISIBLE 20M IP67",
  },
  {
    type: "Almacenamiento",
    code: "WD10PURZ",
    price: 208000,
    category: "DiscoDuro",
    img: "https://cdn-reichelt.de/bilder/web/xxl_ws/E600/WD10PURZ_04.png",
    descripcion: "DISCO DURO 1TB CACHE 64MB 3.5 SATA 5400 RPM 6GB/S",
  },
  {
    type: "CONTROLES DE ACCESO",
    code: "SF400ID-ACCESS",
    price: 400000,
    category: "ControlAcceso",
    img: "https://virtual-go.com/wp-content/uploads/2020/08/SF400Grande.jpg",
    descripcion:
      "TERMINAL CONTROL DE ACCESO PANTALLA TOUCH LCD 2.8 1500 HUELLAS 5000 TARJETAS CON FUENTE CONPATIBLE CON ZK BIOACCESS",
  },
  {
    type: "Electrificadoras",
    code: "ECR18PLUS",
    price: 400000,
    category: "ElementoElectrico",
    img: "https://static3.tcdn.com.br/img/img_prod/332274/cerca_eletrica_jfl_ecr_18_plus_central_modulo_ethernet_aplicativo_celular_controle_remoto_10766_1_20190829162016.jpg",
    descripcion:
      "ELECTRIFICADOR PARA CERCA ELÉCTRICA 18000V EN CTO ABIERTO PULSO 0.5 JOULE RECIBE CONTROL REMOTO",
  },
];
